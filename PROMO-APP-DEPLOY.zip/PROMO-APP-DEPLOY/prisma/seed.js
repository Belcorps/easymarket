/**
 * Crée l'utilisateur de test : test@test.com / test1234
 * Exécution : npx prisma db seed
 */
const { PrismaClient } = require("@prisma/client");
const { hash } = require("bcryptjs");

const prisma = new PrismaClient();

async function main() {
  const email = "test@test.com";
  const password = "test1234";

  const hashedPassword = await hash(password, 12);
  const existing = await prisma.user.findUnique({ where: { email }, include: { profile: true } });

  if (existing) {
    await prisma.user.update({
      where: { email },
      data: { password: hashedPassword, isAdmin: true },
    });
    if (!existing.profile) {
      await prisma.profile.create({
        data: {
          userId: existing.id,
          storeName: "Magasin Test",
          phone: "+33 0 00 00 00 00",
        },
      });
    }
    console.log("OK : Mot de passe réinitialisé pour", email, "→", password);
    return;
  }

  await prisma.user.create({
    data: {
      email,
      password: hashedPassword,
      isAdmin: true,
      profile: {
        create: {
          storeName: "Magasin Test",
          phone: "+33 0 00 00 00 00",
        },
      },
    },
  });

  console.log("OK : Utilisateur créé :", email, "/ mot de passe :", password);
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => {
    console.error(e);
    prisma.$disconnect();
    process.exit(1);
  });
