/**
 * test@test.com kullanıcısını admin yapar.
 * Çalıştır: node scripts/set-admin.js
 */
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  const email = "test@test.com";
  const user = await prisma.user.updateMany({
    where: { email },
    data: { isAdmin: true },
  });
  if (user.count === 0) {
    console.log("Uyarı: " + email + " ile kayıtlı kullanıcı yok. Önce bu e-posta ile kayıt ol.");
    process.exit(1);
  }
  console.log("OK: " + email + " artık admin.");
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => {
    console.error(e);
    prisma.$disconnect();
    process.exit(1);
  });
