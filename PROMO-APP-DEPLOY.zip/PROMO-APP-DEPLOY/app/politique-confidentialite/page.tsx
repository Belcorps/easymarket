import Link from "next/link";

export const metadata = {
  title: "Politique de Confidentialité | Easymarket AI",
  description: "Politique de confidentialité et protection des données - Easymarket AI",
};

export default function PolitiqueConfidentialitePage() {
  return (
    <div className="min-h-screen bg-[#0c0c1a] text-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link href="/" className="text-slate-400 hover:text-white text-sm mb-8 inline-block">
          ← Retour à l&apos;accueil
        </Link>
        <h1 className="text-3xl font-bold mb-8">Politique de Confidentialité</h1>
        <p className="text-slate-400 text-sm mb-8">Dernière mise à jour : 2025</p>

        <div className="prose prose-invert prose-slate max-w-none space-y-6 text-slate-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">1. Responsable du traitement</h2>
            <p>
              Le traitement des données personnelles est réalisé dans le cadre du service Easymarket AI. Pour
              toute question relative à vos données, vous pouvez nous contacter à{" "}
              <a href="mailto:info@belcorps.com">info@belcorps.com</a> ou via WhatsApp au{" "}
              <a href="https://wa.me/32490111555" target="_blank" rel="noreferrer">
                +32 490 11 15 55
              </a>
              .
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">2. Données collectées</h2>
            <p>
              Nous collectons les données nécessaires à la création et à la gestion de votre compte
              (adresse e-mail, nom du commerce, téléphone si renseigné) ainsi qu&apos;aux contenus que vous
              créez (visuels, campagnes, produits). Les images que vous uploadez sont stockées pour
              le fonctionnement du service.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">3. Finalités</h2>
            <p>
              Les données sont utilisées pour fournir le service (création de visuels, authentification,
              sauvegarde de vos campagnes), pour améliorer le service et, le cas échéant, pour vous
              envoyer des informations relatives au service (avec votre accord).
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">4. Base légale et durée</h2>
            <p>
              Le traitement repose sur l&apos;exécution du contrat (utilisation du service) et, le cas échéant,
              sur votre consentement. Les données sont conservées pendant la durée d&apos;utilisation du
              compte et, après clôture, pendant la durée légale ou nécessaire à nos obligations.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">5. Vos droits</h2>
            <p>
              Vous disposez d&apos;un droit d&apos;accès, de rectification, d&apos;effacement, de limitation du
              traitement et, le cas échéant, de portabilité de vos données. Vous pouvez exercer ces droits
              en nous contactant. Vous avez également le droit d&apos;introduire une réclamation auprès de
              l&apos;autorité de contrôle compétente.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">6. Sécurité et sous-traitants</h2>
            <p>
              Nous mettons en œuvre des mesures techniques et organisationnelles pour protéger vos
              données. Certains traitements peuvent être confiés à des sous-traitants (hébergement,
              services d&apos;analyse ou d&apos;images) dans le respect du droit applicable.
            </p>
          </section>
        </div>

        <p className="mt-12 text-slate-500 text-sm">
          <Link href="/" className="text-violet-400 hover:underline">Easymarket AI</Link> ·{" "}
          <Link href="/conditions-generales" className="text-violet-400 hover:underline">CGU</Link> ·{" "}
          <Link href="/terms" className="text-violet-400 hover:underline">Terms of Service</Link> ·{" "}
          <Link href="/politique-cookies" className="text-violet-400 hover:underline">Politique cookies</Link>
        </p>
      </div>
    </div>
  );
}
