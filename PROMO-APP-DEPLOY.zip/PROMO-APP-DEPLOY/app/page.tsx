import { cookies } from "next/headers";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { LandingHeader } from "@/components/LandingHeader";
import { LandingFooter } from "@/components/LandingFooter";
import { ScrollReveal } from "@/components/ScrollReveal";
import { TestimonialsCarousel } from "@/components/TestimonialsCarousel";
import { COOKIE_NAME, getTranslations, type Locale } from "@/lib/i18n";

export default async function LandingPage() {
  const cookieStore = await cookies();
  const locale = (cookieStore.get(COOKIE_NAME)?.value as Locale) ?? "fr";
  const t = getTranslations(locale);

  return (
    <div className="min-h-screen bg-[#0c0c1a] text-white flex flex-col">
      {/* Arrière-plan : dégradés doux bleu/violet */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] bg-violet-600/15 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -left-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
      </div>

      <LandingHeader navLogin={t.navLogin} navRegister={t.navRegister} />

      <main className="relative z-10 flex-1 px-6 py-16 max-w-6xl mx-auto w-full">
        {/* Hero */}
        <section className="min-h-[70vh] flex flex-col justify-center">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="order-2 lg:order-1 flex flex-col items-center lg:items-end">
              <div className="w-full max-w-md space-y-4">
                <div className="text-center lg:text-right">
                  <h2 className="text-lg font-bold text-white mb-1">{t.heroFormatsTitle}</h2>
                  <p className="text-slate-400 text-sm">{t.heroFormatsSub}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-4 sm:p-5">
                    <p className="text-violet-300 font-semibold text-sm mb-2">{t.heroFormatInstagram}</p>
                    <p className="text-slate-400 text-xs sm:text-sm leading-snug">{t.heroFormatInstagramSub}</p>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-4 sm:p-5">
                    <p className="text-violet-300 font-semibold text-sm mb-2">{t.heroFormatFacebook}</p>
                    <p className="text-slate-400 text-xs sm:text-sm leading-snug">{t.heroFormatFacebookSub}</p>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-4 sm:p-5">
                    <p className="text-violet-300 font-semibold text-sm mb-2">{t.heroFormatReels}</p>
                    <p className="text-slate-400 text-xs sm:text-sm leading-snug">{t.heroFormatReelsSub}</p>
                  </div>
                </div>
                <div className="flex justify-center lg:justify-end">
                  <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/15 text-emerald-400 text-sm font-medium border border-emerald-500/30">
                    <span className="w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[10px]">✓</span>
                    {t.feature3}
                  </span>
                </div>
              </div>
            </div>

            <div className="order-1 lg:order-2 text-center lg:text-left">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-violet-500/20 text-violet-300 text-xs font-semibold mb-6 border border-violet-500/30">
                {t.badgePro}
              </span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white mb-4">
                {t.heroTitle}
              </h1>
              <p className="text-lg text-slate-400 max-w-xl mx-auto lg:mx-0 mb-8 leading-relaxed">
                {t.heroSub}
              </p>
              <div className="flex flex-wrap gap-4 justify-center lg:justify-start mb-8">
                <Link
                  href="/register"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-violet-500 to-blue-600 text-white font-semibold text-lg hover:opacity-95 transition-opacity shadow-xl shadow-violet-500/30"
                >
                  <span>{t.ctaStart}</span>
                  <span aria-hidden>→</span>
                </Link>
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/15 text-emerald-400 text-sm font-medium border border-emerald-500/30">
                  <span className="w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[10px]">✓</span>
                  {t.ctaFree}
                </span>
              </div>
              <div className="flex flex-wrap gap-6 justify-center lg:justify-start text-sm">
                <span className="flex items-center gap-2 text-slate-400">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 text-xs">✓</span>
                  {t.feature1}
                </span>
                <span className="flex items-center gap-2 text-slate-400">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 text-xs">✓</span>
                  {t.feature2}
                </span>
                <span className="flex items-center gap-2 text-slate-400">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 text-xs">✓</span>
                  {t.feature3}
                </span>
              </div>
              <div className="mt-10">
                <Link
                  href="/login"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl border-2 border-slate-500/50 text-slate-300 hover:border-violet-500/50 hover:text-violet-300 font-semibold transition-colors"
                >
                  <span>▷</span>
                  <span>{t.ctaLogin}</span>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* En 3 étapes */}
        <ScrollReveal className="py-24">
          <h2 className="text-2xl sm:text-3xl font-bold text-white text-center mb-12">
            {t.section3Steps}
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "1", title: t.step1Title, desc: t.step1Desc, icon: "▣" },
              { step: "2", title: t.step2Title, desc: t.step2Desc, icon: "✨" },
              { step: "3", title: t.step3Title, desc: t.step3Desc, icon: "🚀" },
            ].map((item, i) => (
              <ScrollReveal key={item.step} delay={i * 100}>
                <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-6 h-full flex flex-col">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-violet-500 to-blue-600 flex items-center justify-center text-xl mb-4">
                    {item.icon}
                  </div>
                  <p className="text-violet-300 text-sm font-semibold mb-1">
                    {t.stepLabel} {item.step}
                  </p>
                  <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed flex-1">{item.desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </ScrollReveal>

        {/* Pourquoi nous */}
        <ScrollReveal className="py-24 border-t border-white/5">
          <h2 className="text-2xl sm:text-3xl font-bold text-white text-center mb-4">
            {t.sectionWhy}
          </h2>
          <p className="text-slate-400 text-center max-w-2xl mx-auto mb-12">
            {t.sectionWhySub}
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: t.why1, icon: "✓" },
              { label: t.why2, icon: "✓" },
              { label: t.why3, icon: "✓" },
              { label: t.why4, icon: "✓" },
            ].map((item, i) => (
              <ScrollReveal key={item.label} delay={i * 80}>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
                  <span className="text-emerald-400 text-xl block mb-2">{item.icon}</span>
                  <span className="text-white font-medium text-sm">{item.label}</span>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </ScrollReveal>

        {/* Marchés qui nous font confiance - carousel */}
        <ScrollReveal className="py-24 border-t border-white/5">
          <h2 className="text-2xl sm:text-3xl font-bold text-white text-center mb-12">
            {t.sectionTrustTitle}
          </h2>
          <TestimonialsCarousel t={t} />
        </ScrollReveal>
      </main>

      <LandingFooter locale={locale} t={t} />
    </div>
  );
}
