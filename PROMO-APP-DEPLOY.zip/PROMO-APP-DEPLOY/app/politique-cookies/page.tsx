import Link from "next/link";

export const metadata = {
  title: "Politique en matière de Cookies | Easymarket AI",
  description: "Politique d'utilisation des cookies - Easymarket AI",
};

export default function PolitiqueCookiesPage() {
  return (
    <div className="min-h-screen bg-[#0c0c1a] text-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link href="/" className="text-slate-400 hover:text-white text-sm mb-8 inline-block">
          ← Retour à l&apos;accueil
        </Link>
        <h1 className="text-3xl font-bold mb-8">Politique en matière de Cookies</h1>
        <p className="text-slate-400 text-sm mb-8">Dernière mise à jour : 2025</p>

        <div className="prose prose-invert prose-slate max-w-none space-y-6 text-slate-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">1. Qu&apos;est-ce qu&apos;un cookie ?</h2>
            <p>
              Un cookie est un petit fichier texte déposé sur votre terminal (ordinateur, tablette, smartphone)
              lors de la visite d&apos;un site. Il permet de mémoriser des informations sur votre navigation ou
              vos préférences.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">2. Cookies utilisés sur Easymarket AI</h2>
            <p>
              Nous utilisons des cookies strictement nécessaires au fonctionnement du site : session
              d&apos;authentification, préférence de langue et éventuellement des cookies techniques pour la
              stabilité et la sécurité. Nous pouvons également utiliser des cookies pour mémoriser vos choix
              d&apos;affichage (thème clair/sombre).
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">3. Durée de conservation</h2>
            <p>
              Les cookies de session sont supprimés à la fermeture du navigateur. Les cookies de
              préférence (par exemple la langue) peuvent être conservés pendant une durée plus longue
              pour améliorer votre expérience.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">4. Gestion des cookies</h2>
            <p>
              Vous pouvez configurer votre navigateur pour refuser ou supprimer certains cookies.
              Cela peut affecter certaines fonctionnalités du site (connexion, préférences). Les paramètres
              se trouvent généralement dans les options ou préférences de votre navigateur.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">5. Cookies tiers</h2>
            <p>
              Si nous intégrons des services tiers (analytics, outils de support), ceux-ci peuvent déposer
              leurs propres cookies. Nous vous informons des catégories de cookies utilisés et, le cas
              échéant, des moyens de les refuser, conformément à la réglementation en vigueur.
            </p>
          </section>
        </div>

        <p className="mt-12 text-slate-500 text-sm">
          <Link href="/" className="text-violet-400 hover:underline">Easymarket AI</Link> ·{" "}
          <Link href="/conditions-generales" className="text-violet-400 hover:underline">CGU</Link> ·{" "}
          <Link href="/politique-confidentialite" className="text-violet-400 hover:underline">Politique de confidentialité</Link> ·{" "}
          <Link href="/terms" className="text-violet-400 hover:underline">Terms of Service</Link>
        </p>
      </div>
    </div>
  );
}
