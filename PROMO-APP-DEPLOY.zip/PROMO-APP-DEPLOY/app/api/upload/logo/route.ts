import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { uploadToSupabase } from "@/lib/supabase-server";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads", "logos");

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  const removeBg = formData.get("removeBg") === "true";

  if (!file?.size) {
    return NextResponse.json({ error: "Fichier requis" }, { status: 400 });
  }

  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) {
    return NextResponse.json(
      { error: "Format accepté : JPG, PNG, WebP" },
      { status: 400 }
    );
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
    include: { profile: true },
  });
  if (!user?.profile) {
    return NextResponse.json({ error: "Profil non trouvé" }, { status: 404 });
  }

  let buffer = Buffer.from(await file.arrayBuffer());
  let contentType = file.type;

  if (removeBg && process.env.REMOVE_BG_API_KEY) {
    const removeBgRes = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers: {
        "X-Api-Key": process.env.REMOVE_BG_API_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        image_file_b64: buffer.toString("base64"),
        size: "auto",
      }),
    });
    if (removeBgRes.ok) {
      const blob = await removeBgRes.blob();
      buffer = Buffer.from(await blob.arrayBuffer());
      contentType = blob.type || "image/png";
    }
  }

  let logoUrl: string;
  const supabaseResult = await uploadToSupabase(`logos/${user.id}`, buffer, contentType);
  if (supabaseResult) {
    logoUrl = supabaseResult.url;
  } else {
    await mkdir(UPLOAD_DIR, { recursive: true });
    const ext = contentType.includes("png") ? "png" : "jpg";
    const filename = `${user.id}-${Date.now()}.${ext}`;
    const filepath = path.join(UPLOAD_DIR, filename);
    await writeFile(filepath, buffer);
    logoUrl = `/uploads/logos/${filename}`;
  }

  await prisma.profile.update({
    where: { userId: user.id },
    data: { logoUrl },
  });

  return NextResponse.json({ ok: true, logoUrl });
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
    include: { profile: true },
  });
  if (!user?.profile) {
    return NextResponse.json({ error: "Profil non trouvé" }, { status: 404 });
  }
  await prisma.profile.update({
    where: { userId: user.id },
    data: { logoUrl: null },
  });
  return NextResponse.json({ ok: true });
}
