import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { authOptions } from "@/lib/auth";

/**
 * POST: envoie une image, reçoit la même image avec arrière-plan supprimé (remove.bg).
 * Nécessite REMOVE_BG_API_KEY dans .env.
 */
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }

  const apiKey = process.env.REMOVE_BG_API_KEY?.trim();
  if (!apiKey) {
    return NextResponse.json(
      { error: "Suppression d'arrière-plan non configurée (REMOVE_BG_API_KEY)." },
      { status: 503 }
    );
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  if (!file?.size) {
    return NextResponse.json({ error: "Fichier requis" }, { status: 400 });
  }

  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) {
    return NextResponse.json(
      { error: "Format accepté : JPG, PNG, WebP" },
      { status: 400 }
    );
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const removeBgRes = await fetch("https://api.remove.bg/v1.0/removebg", {
    method: "POST",
    headers: {
      "X-Api-Key": apiKey,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      image_file_b64: buffer.toString("base64"),
      size: "auto",
    }),
  });

  if (!removeBgRes.ok) {
    const err = await removeBgRes.text();
    return NextResponse.json(
      { error: "Erreur remove.bg: " + (err || removeBgRes.statusText) },
      { status: 502 }
    );
  }

  const blob = await removeBgRes.blob();
  const arrayBuffer = await blob.arrayBuffer();
  return new NextResponse(arrayBuffer, {
    headers: {
      "Content-Type": blob.type || "image/png",
    },
  });
}
