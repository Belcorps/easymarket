import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const updateSchema = z.object({
  name: z.string().min(1).optional(),
  formatType: z.enum(["instagram_post_portrait", "instagram_post_square", "facebook_post", "reel"]).optional(),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  showAddress: z.boolean().optional(),
  showPhone: z.boolean().optional(),
  showDiscountPct: z.boolean().optional(),
  language: z.string().optional(),
  language2: z.string().optional().nullable(),
  currency: z.string().optional(),
  products: z
    .array(
      z.object({
        productId: z.string(),
        order: z.number(),
        oldPrice: z.string().optional().nullable(),
        newPrice: z.string().optional().nullable(),
        halal: z.boolean().optional(),
        bio: z.boolean().optional(),
        vegan: z.boolean().optional(),
        newIcon: z.boolean().optional(),
      })
    )
    .optional(),
});

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const { id } = await params;
  const campaign = await prisma.campaign.findFirst({
    where: { id },
    include: {
      products: { include: { product: true }, orderBy: { order: "asc" } },
    },
  });
  if (!campaign) return NextResponse.json({ error: "Non trouvé" }, { status: 404 });
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (campaign.userId !== user?.id) return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  return NextResponse.json(campaign);
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const { id } = await params;
  const campaign = await prisma.campaign.findFirst({ where: { id } });
  if (!campaign) return NextResponse.json({ error: "Non trouvé" }, { status: 404 });
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (campaign.userId !== user?.id) return NextResponse.json({ error: "Non autorisé" }, { status: 403 });

  try {
    const body = await req.json();
    const data = updateSchema.parse(body);

    if (data.products !== undefined) {
      await prisma.campaignProduct.deleteMany({ where: { campaignId: id } });
      if (data.products.length > 0) {
        await prisma.campaignProduct.createMany({
          data: data.products.map((p) => ({
            campaignId: id,
            productId: p.productId,
            order: p.order,
            oldPrice: p.oldPrice ?? null,
            newPrice: p.newPrice ?? null,
            halal: p.halal ?? false,
            bio: p.bio ?? false,
            vegan: p.vegan ?? false,
            newIcon: p.newIcon ?? false,
          })),
        });
      }
    }

    const updated = await prisma.campaign.update({
      where: { id },
      data: {
        ...(data.name != null && { name: data.name }),
        ...(data.formatType != null && { formatType: data.formatType }),
        ...(data.startDate !== undefined && {
          startDate: data.startDate ? new Date(data.startDate) : null,
        }),
        ...(data.endDate !== undefined && {
          endDate: data.endDate ? new Date(data.endDate) : null,
        }),
        ...(data.showAddress != null && { showAddress: data.showAddress }),
        ...(data.showPhone != null && { showPhone: data.showPhone }),
        ...(data.showDiscountPct != null && { showDiscountPct: data.showDiscountPct }),
        ...(data.language != null && { language: data.language }),
        ...(data.language2 !== undefined && { language2: data.language2 }),
        ...(data.currency != null && { currency: data.currency }),
      },
      include: {
        products: { include: { product: true }, orderBy: { order: "asc" } },
      },
    });
    return NextResponse.json(updated);
  } catch (e) {
    if (e instanceof z.ZodError) {
      return NextResponse.json(
        { error: e.errors[0]?.message ?? "Données invalides" },
        { status: 400 }
      );
    }
    return NextResponse.json({ error: "Erreur" }, { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const { id } = await params;
  const campaign = await prisma.campaign.findFirst({ where: { id } });
  if (!campaign) return NextResponse.json({ error: "Non trouvé" }, { status: 404 });
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (campaign.userId !== user?.id) return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  await prisma.campaign.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
