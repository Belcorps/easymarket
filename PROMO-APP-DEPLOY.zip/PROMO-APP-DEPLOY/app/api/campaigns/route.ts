import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const createSchema = z.object({
  name: z.string().min(1),
  templateId: z.string().min(1),
  formatType: z.enum(["instagram_post_portrait", "instagram_post_square", "facebook_post", "reel"]).optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  showAddress: z.boolean().optional(),
  showPhone: z.boolean().optional(),
  showDiscountPct: z.boolean().optional(),
  language: z.string().optional(),
  language2: z.string().optional(),
  currency: z.string().optional(),
  products: z.array(z.object({ productId: z.string(), order: z.number(), oldPrice: z.string().optional(), newPrice: z.string().optional(), halal: z.boolean().optional(), bio: z.boolean().optional(), vegan: z.boolean().optional(), newIcon: z.boolean().optional() })).optional(),
}).strict(false);

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!user) return NextResponse.json({ error: "Non trouvé" }, { status: 404 });

  const campaigns = await prisma.campaign.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    include: {
      products: { include: { product: true }, orderBy: { order: "asc" } },
    },
  });
  return NextResponse.json(campaigns);
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!user) return NextResponse.json({ error: "Non trouvé" }, { status: 404 });

  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    const startDate = data.startDate ? new Date(data.startDate) : null;
    const endDate = data.endDate ? new Date(data.endDate) : null;

    const campaign = await prisma.campaign.create({
      data: {
        userId: user.id,
        name: data.name,
        templateId: data.templateId,
        formatType: data.formatType ?? "instagram_post_portrait",
        startDate,
        endDate,
        showAddress: data.showAddress ?? true,
        showPhone: data.showPhone ?? true,
        showDiscountPct: data.showDiscountPct ?? false,
        language: data.language ?? "fr",
        language2: data.language2 ?? null,
        currency: data.currency ?? "€",
        products: data.products?.length
          ? {
              create: data.products.map((p, i) => ({
                productId: p.productId,
                order: p.order ?? i,
                oldPrice: p.oldPrice ?? null,
                newPrice: p.newPrice ?? null,
                halal: p.halal ?? false,
                bio: p.bio ?? false,
                vegan: p.vegan ?? false,
                newIcon: p.newIcon ?? false,
              })),
            }
          : undefined,
      },
      include: {
        products: { include: { product: true }, orderBy: { order: "asc" } },
      },
    });
    return NextResponse.json(campaign);
  } catch (e) {
    if (e instanceof z.ZodError) {
      return NextResponse.json(
        { error: e.errors[0]?.message ?? "Données invalides" },
        { status: 400 }
      );
    }
    return NextResponse.json({ error: "Erreur" }, { status: 500 });
  }
}
