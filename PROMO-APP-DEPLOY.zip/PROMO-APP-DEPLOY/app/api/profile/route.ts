import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const bodySchema = z.object({
  storeName: z.string().min(1).optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
});

export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const data = bodySchema.parse(body);

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      include: { profile: true },
    });
    if (!user?.profile) {
      return NextResponse.json({ error: "Profil non trouvé" }, { status: 404 });
    }

    await prisma.profile.update({
      where: { id: user.profile.id },
      data: {
        ...(data.storeName !== undefined && { storeName: data.storeName }),
        ...(data.phone !== undefined && { phone: data.phone || null }),
        ...(data.address !== undefined && { address: data.address || null }),
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    if (e instanceof z.ZodError) {
      return NextResponse.json(
        { error: e.errors[0]?.message ?? "Données invalides" },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour." },
      { status: 500 }
    );
  }
}
