import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const createSchema = z.object({
  name: z.string().min(1),
  brand: z.string().optional(),
  category: z.string().optional(),
  imageUrl: z.string().optional(),
  unit: z.string().optional(),
});

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") ?? "";
  const category = searchParams.get("category") ?? "";

  const where: { name?: { contains: string }; category?: string } = {};
  if (q) where.name = { contains: q };
  if (category) where.category = category;

  const products = await prisma.product.findMany({
    where,
    orderBy: { name: "asc" },
    take: 100,
  });
  const categories = await prisma.product.findMany({
    select: { category: true },
    where: { category: { not: null } },
    distinct: ["category"],
  });
  const total = await prisma.product.count();

  return NextResponse.json({
    products,
    categories: categories.map((c) => c.category).filter(Boolean) as string[],
    total,
  });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
  }
  try {
    const body = await req.json();
    const data = createSchema.parse(body);
    const product = await prisma.product.create({
      data: {
        name: data.name,
        brand: data.brand ?? null,
        category: data.category ?? null,
        imageUrl: data.imageUrl ?? null,
        unit: data.unit ?? null,
      },
    });
    return NextResponse.json(product);
  } catch (e) {
    if (e instanceof z.ZodError) {
      return NextResponse.json(
        { error: e.errors[0]?.message ?? "Données invalides" },
        { status: 400 }
      );
    }
    return NextResponse.json({ error: "Erreur" }, { status: 500 });
  }
}
