import Link from "next/link";

export const metadata = {
  title: "Conditions Générales d'Utilisation | Easymarket AI",
  description: "Conditions générales d'utilisation du service Easymarket AI",
};

export default function ConditionsGeneralesPage() {
  return (
    <div className="min-h-screen bg-[#0c0c1a] text-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link href="/" className="text-slate-400 hover:text-white text-sm mb-8 inline-block">
          ← Retour à l&apos;accueil
        </Link>
        <h1 className="text-3xl font-bold mb-8">Conditions Générales d&apos;Utilisation</h1>
        <p className="text-slate-400 text-sm mb-8">Dernière mise à jour : 2025</p>

        <div className="prose prose-invert prose-slate max-w-none space-y-6 text-slate-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">1. Objet et acceptation</h2>
            <p>
              Les présentes Conditions Générales d&apos;Utilisation (CGU) régissent l&apos;accès et
              l&apos;utilisation du service Easymarket AI. En utilisant le service, vous acceptez les présentes
              CGU sans réserve.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">2. Description du service</h2>
            <p>
              Easymarket AI met à disposition des outils de création de visuels promotionnels pour supermarchés
              et commerces : modèles d&apos;affiches, intégration produits, export pour les réseaux sociaux
              (Instagram, Facebook, Reels).
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">3. Compte et utilisation</h2>
            <p>
              L&apos;inscription nécessite des informations exactes. Vous êtes responsable de la confidentialité
              de vos identifiants et de toute activité réalisée depuis votre compte.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">4. Usage acceptable</h2>
            <p>
              Vous vous engagez à ne pas utiliser le service à des fins illicites, pour porter atteinte aux
              droits de tiers ou pour diffuser des contenus illégaux ou préjudiciables. Tout manquement
              peut entraîner la suspension ou la résiliation du compte.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">5. Propriété intellectuelle</h2>
            <p>
              Le service et son contenu (hors contenus créés par les utilisateurs) sont protégés par le droit
              de la propriété intellectuelle. Vous conservez la propriété des contenus que vous créez ; vous
              nous accordez une licence pour les exploiter dans le cadre du service.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">6. Limitation de responsabilité</h2>
            <p>
              Le service est fourni « en l&apos;état ». Nous ne pouvons être tenus responsables des dommages
              indirects résultant de l&apos;utilisation du service.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">7. Modifications</h2>
            <p>
              Nous nous réservons le droit de modifier les présentes CGU. La poursuite de l&apos;utilisation
              après modification vaut acceptation. Les utilisateurs seront informés des changements
              importants lorsque cela est pertinent.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">8. Contact</h2>
            <p>
              Pour toute question relative aux présentes CGU, vous pouvez nous contacter via les
              coordonnées indiquées sur le site.
            </p>
          </section>
        </div>

        <p className="mt-12 text-slate-500 text-sm">
          <Link href="/" className="text-violet-400 hover:underline">Easymarket AI</Link> ·{" "}
          <Link href="/terms" className="text-violet-400 hover:underline">Terms of Service</Link> ·{" "}
          <Link href="/politique-confidentialite" className="text-violet-400 hover:underline">Politique de confidentialité</Link> ·{" "}
          <Link href="/politique-cookies" className="text-violet-400 hover:underline">Politique cookies</Link>
        </p>
      </div>
    </div>
  );
}
