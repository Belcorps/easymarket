import Link from "next/link";

export const metadata = {
  title: "Contact | Easymarket AI",
  description: "Contact Belcorps Agency pour Easymarket AI",
};

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-[#0c0c1a] text-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link href="/" className="text-slate-400 hover:text-white text-sm mb-8 inline-block">
          ← Retour à l&apos;accueil
        </Link>

        <h1 className="text-3xl font-bold mb-4">Contact</h1>
        <p className="text-slate-400 text-sm mb-8">
          Easymarket AI est conçu et opéré par <span className="font-semibold">Belcorps Agency</span>. Pour toute
          question, support ou partenariat, vous pouvez nous joindre via les canaux ci-dessous.
        </p>

        <div className="space-y-6 text-slate-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">Email</h2>
            <p className="mb-2">
              Pour toute demande (support, démo, facturation, partenariat), envoyez-nous un email :
            </p>
            <a
              href="mailto:info@belcorps.com"
              className="inline-flex items-center gap-2 text-violet-300 hover:text-violet-200 transition-colors"
            >
              <span aria-hidden>✉️</span>
              <span>info@belcorps.com</span>
            </a>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-2">WhatsApp</h2>
            <p className="mb-2">
              Pour une réponse rapide, vous pouvez aussi nous écrire sur WhatsApp :
            </p>
            <a
              href="https://wa.me/32490111555"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 text-emerald-300 hover:text-emerald-200 transition-colors"
            >
              <span aria-hidden>🟢</span>
              <span>WhatsApp +32 490 11 15 55</span>
            </a>
          </section>
        </div>

        <p className="mt-12 text-slate-500 text-sm">
          <Link href="/" className="text-violet-400 hover:underline">
            Easymarket AI
          </Link>
          {" · "}
          <Link href="/conditions-generales" className="text-violet-400 hover:underline">
            CGU
          </Link>
          {" · "}
          <Link href="/politique-confidentialite" className="text-violet-400 hover:underline">
            Politique de confidentialité
          </Link>
          {" · "}
          <Link href="/politique-cookies" className="text-violet-400 hover:underline">
            Politique cookies
          </Link>
        </p>
      </div>
    </div>
  );
}

