import Link from "next/link";

export const metadata = {
  title: "Terms of Service | Easymarket AI",
  description: "Terms of Service for Easymarket AI",
};

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-[#0c0c1a] text-white">
      <div className="max-w-3xl mx-auto px-6 py-16">
        <Link href="/" className="text-slate-400 hover:text-white text-sm mb-8 inline-block">
          ← Back to home
        </Link>
        <h1 className="text-3xl font-bold mb-8">Terms of Service</h1>
        <p className="text-slate-400 text-sm mb-8">Last updated: 2025</p>

        <div className="prose prose-invert prose-slate max-w-none space-y-6 text-slate-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">1. Acceptance of Terms</h2>
            <p>
              By accessing or using Easymarket AI (&quot;Service&quot;), you agree to be bound by these Terms of
              Service. If you do not agree, do not use the Service.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">2. Description of Service</h2>
            <p>
              Easymarket AI provides tools to create promotional visuals for supermarkets and retail: templates,
              product integration, export for social networks (Instagram, Facebook, Reels).
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">3. Account and Use</h2>
            <p>
              You must provide accurate information when registering. You are responsible for keeping your
              credentials secure and for all activity under your account.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">4. Acceptable Use</h2>
            <p>
              You may not use the Service for illegal purposes, to infringe others&apos; rights, or to transmit
              harmful or offensive content. We may suspend or terminate accounts that violate these terms.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">5. Intellectual Property</h2>
            <p>
              The Service and its content (excluding user-generated content) are owned by Easymarket AI. You
              retain rights to the content you create; you grant us a licence to operate and display it within
              the Service.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">6. Limitation of Liability</h2>
            <p>
              The Service is provided &quot;as is&quot;. We are not liable for indirect, incidental, or consequential
              damages arising from your use of the Service.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">7. Changes</h2>
            <p>
              We may update these Terms. Continued use after changes constitutes acceptance. We will notify
              users of material changes where appropriate.
            </p>
          </section>
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">8. Contact</h2>
            <p>
              For questions about these Terms, you can contact us at{" "}
              <a href="mailto:info@belcorps.com">info@belcorps.com</a> or on WhatsApp at{" "}
              <a href="https://wa.me/32490111555" target="_blank" rel="noreferrer">
                +32 490 11 15 55
              </a>
              .
            </p>
          </section>
        </div>

        <p className="mt-12 text-slate-500 text-sm">
          <Link href="/" className="text-violet-400 hover:underline">Easymarket AI</Link> ·{" "}
          <Link href="/conditions-generales" className="text-violet-400 hover:underline">CGU (FR)</Link> ·{" "}
          <Link href="/politique-confidentialite" className="text-violet-400 hover:underline">Privacy</Link> ·{" "}
          <Link href="/politique-cookies" className="text-violet-400 hover:underline">Cookies</Link>
        </p>
      </div>
    </div>
  );
}
