import "next-auth";

declare module "next-auth" {
  interface User {
    id?: string;
    hasProfile?: boolean;
    isAdmin?: boolean;
  }

  interface Session {
    user: User & { id?: string; hasProfile?: boolean; isAdmin?: boolean };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    hasProfile?: boolean;
    isAdmin?: boolean;
  }
}
