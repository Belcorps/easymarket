export type Locale = "fr" | "en" | "nl" | "de";

export const COOKIE_NAME = "NEXT_LOCALE";

export const LOCALE_LABELS: Record<Locale, string> = {
  fr: "Français",
  en: "English",
  nl: "Nederlands",
  de: "Deutsch",
};

export type LandingTranslations = {
  navLogin: string;
  navRegister: string;
  badgePro: string;
  heroTitle: string;
  heroSub: string;
  ctaStart: string;
  ctaLogin: string;
  ctaFree: string;
  feature1: string;
  feature2: string;
  feature3: string;
  section3Steps: string;
  stepLabel: string; // "Étape" / "Step" / "Stap" / "Schritt"
  step1Title: string;
  step1Desc: string;
  step2Title: string;
  step2Desc: string;
  step3Title: string;
  step3Desc: string;
  sectionWhy: string;
  sectionWhySub: string;
  why1: string;
  why2: string;
  why3: string;
  why4: string;
  ctaCampaign: string;
  footerProduct: string;
  footerSupport: string;
  footerTerms: string;
  footerPrivacy: string;
  footerCookies: string;
  footerCgu: string;
  footerRights: string;
  heroFormatsTitle: string;
  heroFormatsSub: string;
  heroFormatInstagram: string;
  heroFormatInstagramSub: string;
  heroFormatFacebook: string;
  heroFormatFacebookSub: string;
  heroFormatReels: string;
  heroFormatReelsSub: string;
  sectionTrustTitle: string;
  testimonial1Market: string;
  testimonial1Quote: string;
  testimonial2Market: string;
  testimonial2Quote: string;
  testimonial3Market: string;
  testimonial3Quote: string;
};

const fr: LandingTranslations = {
  navLogin: "Connexion",
  navRegister: "S'inscrire",
  badgePro: "Outil pro",
  heroTitle: "Créez des visuels promo en un clic",
  heroSub:
    "Générez des visuels pour vos promos en quelques secondes : templates, IA pour l'arrière-plan, export Instagram, Facebook et Reels.",
  ctaStart: "Essayer gratuitement",
  ctaLogin: "Se connecter",
  ctaFree: "0 € pour commencer",
  feature1: "Templates prêts à l'emploi",
  feature2: "IA intégrée (arrière-plan)",
  feature3: "Gagnez du temps et partagez plus vite",
  section3Steps: "De l'idée au visuel en 3 étapes",
  stepLabel: "Étape",
  step1Title: "Choisissez un modèle",
  step1Desc: "Sélectionnez un template adapté à votre marché. Les modèles sont prêts pour Instagram, Facebook et Reels.",
  step2Title: "Ajoutez vos produits",
  step2Desc: "Sélectionnez les produits en base, saisissez les prix. L'IA peut retirer l'arrière-plan des photos.",
  step3Title: "Téléchargez ou partagez",
  step3Desc: "Exportez vos visuels aux bonnes dimensions. Publiez sur les réseaux ou imprimez.",
  sectionWhy: "Pourquoi Easymarket AI ?",
  sectionWhySub:
    "Créez vos visuels sans community manager. Partagez en un clic. Bientôt : publication automatique sur Facebook et Instagram.",
  why1: "Sans community manager",
  why2: "Partagez en un clic",
  why3: "Bientôt : publication auto Facebook",
  why4: "Formats Instagram, Facebook, Reels",
  ctaCampaign: "Créer ma première campagne",
  footerProduct: "Produit",
  footerSupport: "Aide & Contacts",
  footerTerms: "Terms of Service",
  footerPrivacy: "Politique de Confidentialité",
  footerCookies: "Politique en matière de Cookies",
  footerCgu: "Conditions Générales d'Utilisation",
  footerRights: "Tous droits réservés",
  heroFormatsTitle: "Vos visuels, tous les formats",
  heroFormatsSub: "Exportez aux bonnes dimensions pour chaque réseau en un clic. Aucun logiciel compliqué : créez, exportez, partagez.",
  heroFormatInstagram: "Instagram",
  heroFormatInstagramSub: "Carré et portrait, prêt à publier. Idéal pour le feed et les stories.",
  heroFormatFacebook: "Facebook",
  heroFormatFacebookSub: "Paysage et couverture, posts et bannières. Dimensions optimisées.",
  heroFormatReels: "Reels",
  heroFormatReelsSub: "Format vertical pour stories et courtes vidéos. Un export, tous les canaux.",
  sectionTrustTitle: "Des marchés qui nous font confiance",
  testimonial1Market: "Marché du Centre",
  testimonial1Quote: "Depuis Easymarket AI, tout est plus simple. Je gère mes promos au quotidien, plus besoin d’attendre qui que ce soit.",
  testimonial2Market: "Super Frais",
  testimonial2Quote: "Mes visuels sont prêts en quelques clics. Je les partage directement, sans passer par un graphiste.",
  testimonial3Market: "Primeur du Quartier",
  testimonial3Quote: "Je fais mes promos tous les jours au lieu d’une fois par semaine. Gain de temps énorme.",
};

const en: LandingTranslations = {
  navLogin: "Log in",
  navRegister: "Sign up",
  badgePro: "Pro tool",
  heroTitle: "Create promo visuals in one click",
  heroSub:
    "Generate promo visuals in seconds: templates, AI background removal, export for Instagram, Facebook and Reels.",
  ctaStart: "Try for free",
  ctaLogin: "Log in",
  ctaFree: "$0 to get started",
  feature1: "Ready-to-use templates",
  feature2: "Built-in AI (background)",
  feature3: "Save time and share faster",
  section3Steps: "From idea to visual in 3 steps",
  stepLabel: "Step",
  step1Title: "Choose a template",
  step1Desc: "Select a template suited to your market. Templates are ready for Instagram, Facebook and Reels.",
  step2Title: "Add your products",
  step2Desc: "Select products from your base, enter prices. AI can remove the background from photos.",
  step3Title: "Download or share",
  step3Desc: "Export your visuals in the right dimensions. Publish on social networks or print.",
  sectionWhy: "Why Easymarket AI?",
  sectionWhySub:
    "Create visuals without a content manager. Share in one click. Coming soon: automatic posting to Facebook and Instagram.",
  why1: "No content manager needed",
  why2: "Share in one click",
  why3: "Coming soon: auto Facebook post",
  why4: "Instagram, Facebook, Reels formats",
  ctaCampaign: "Create my first campaign",
  footerProduct: "Product",
  footerSupport: "Help & Contacts",
  footerTerms: "Terms of Service",
  footerPrivacy: "Privacy Policy",
  footerCookies: "Cookie Policy",
  footerCgu: "Terms of Use",
  footerRights: "All rights reserved",
  heroFormatsTitle: "Your visuals, every format",
  heroFormatsSub: "Export in the right size for each network in one click. No complex software: create, export, share.",
  heroFormatInstagram: "Instagram",
  heroFormatInstagramSub: "Square and portrait, ready to post. Perfect for feed and stories.",
  heroFormatFacebook: "Facebook",
  heroFormatFacebookSub: "Landscape and cover, posts and banners. Optimized dimensions.",
  heroFormatReels: "Reels",
  heroFormatReelsSub: "Vertical format for stories and short videos. One export, all channels.",
  sectionTrustTitle: "Markets that trust us",
  testimonial1Market: "Central Market",
  testimonial1Quote: "Since Easymarket AI, everything is easier. I manage my promos daily, no need to wait for anyone.",
  testimonial2Market: "Super Fresh",
  testimonial2Quote: "My visuals are ready in a few clicks. I share them directly, no designer needed.",
  testimonial3Market: "Corner Greengrocer",
  testimonial3Quote: "I do my promos every day instead of once a week. Huge time saver.",
};

const nl: LandingTranslations = {
  navLogin: "Inloggen",
  navRegister: "Registreren",
  badgePro: "Pro tool",
  heroTitle: "Maak promovisuals in één klik",
  heroSub:
    "Genereer promovisuals in seconden: sjablonen, AI voor achtergrondverwijdering, export voor Instagram, Facebook en Reels.",
  ctaStart: "Gratis proberen",
  ctaLogin: "Inloggen",
  ctaFree: "€0 om te starten",
  feature1: "Klaar-voor-gebruik sjablonen",
  feature2: "Ingebouwde AI (achtergrond)",
  feature3: "Bespaar tijd en deel sneller",
  section3Steps: "Van idee tot visueel in 3 stappen",
  stepLabel: "Stap",
  step1Title: "Kies een sjabloon",
  step1Desc: "Selecteer een sjabloon voor uw markt. Sjablonen zijn klaar voor Instagram, Facebook en Reels.",
  step2Title: "Voeg uw producten toe",
  step2Desc: "Selecteer producten uit uw basis, voer prijzen in. AI kan de achtergrond van foto's verwijderen.",
  step3Title: "Download of deel",
  step3Desc: "Exporteer uw visuals in de juiste afmetingen. Publiceer op sociale netwerken of print.",
  sectionWhy: "Waarom Easymarket AI?",
  sectionWhySub:
    "Maak visuals zonder community manager. Deel in één klik. Binnenkort: automatisch posten op Facebook en Instagram.",
  why1: "Geen community manager",
  why2: "Deel in één klik",
  why3: "Binnenkort: auto Facebook-post",
  why4: "Instagram, Facebook, Reels",
  ctaCampaign: "Mijn eerste campagne maken",
  footerProduct: "Product",
  footerSupport: "Hulp & Contact",
  footerTerms: "Algemene Voorwaarden",
  footerPrivacy: "Privacybeleid",
  footerCookies: "Cookiebeleid",
  footerCgu: "Gebruiksvoorwaarden",
  footerRights: "Alle rechten voorbehouden",
  heroFormatsTitle: "Uw visuals, elk formaat",
  heroFormatsSub: "Exporteer in het juiste formaat per netwerk. Eén klik, meerdere formaten.",
  heroFormatInstagram: "Instagram",
  heroFormatInstagramSub: "Vierkant en portret, klaar om te plaatsen.",
  heroFormatFacebook: "Facebook",
  heroFormatFacebookSub: "Landschap en omslag, posts en banners.",
  heroFormatReels: "Reels",
  heroFormatReelsSub: "Verticaal, stories en korte video's.",
  sectionTrustTitle: "Markten die ons vertrouwen",
  testimonial1Market: "Markt van het Centrum",
  testimonial1Quote: "Sinds Easymarket AI gaat alles makkelijker. Ik beheer mijn promos dagelijks, zonder op iemand te wachten.",
  testimonial2Market: "Super Vers",
  testimonial2Quote: "Mijn visuals zijn in een paar klikken klaar. Ik deel ze direct, geen ontwerper nodig.",
  testimonial3Market: "Groenteboer om de hoek",
  testimonial3Quote: "Ik doe mijn promos nu elke dag in plaats van wekelijks. Enorme tijdsbesparing.",
};

const de: LandingTranslations = {
  navLogin: "Anmelden",
  navRegister: "Registrieren",
  badgePro: "Pro-Tool",
  heroTitle: "Promo-Visuals mit einem Klick erstellen",
  heroSub:
    "Erstellen Sie Promo-Visuals in Sekunden: Vorlagen, KI für Hintergrundentfernung, Export für Instagram, Facebook und Reels.",
  ctaStart: "Kostenlos testen",
  ctaLogin: "Anmelden",
  ctaFree: "0 € zum Starten",
  feature1: "Fertige Vorlagen",
  feature2: "Integrierte KI (Hintergrund)",
  feature3: "Zeit sparen und schneller teilen",
  section3Steps: "Von der Idee zum Visual in 3 Schritten",
  stepLabel: "Schritt",
  step1Title: "Vorlage wählen",
  step1Desc: "Wählen Sie eine Vorlage für Ihren Markt. Vorlagen sind für Instagram, Facebook und Reels bereit.",
  step2Title: "Produkte hinzufügen",
  step2Desc: "Wählen Sie Produkte aus Ihrer Basis, geben Sie Preise ein. KI kann den Hintergrund von Fotos entfernen.",
  step3Title: "Herunterladen oder teilen",
  step3Desc: "Exportieren Sie Ihre Visuals in den richtigen Formaten. Veröffentlichen Sie in sozialen Netzwerken oder drucken Sie.",
  sectionWhy: "Warum Easymarket AI?",
  sectionWhySub:
    "Erstellen Sie Visuals ohne Community Manager. Ein Klick zum Teilen. Bald: automatische Veröffentlichung auf Facebook und Instagram.",
  why1: "Kein Community Manager nötig",
  why2: "Teilen in einem Klick",
  why3: "Bald: Auto-Post auf Facebook",
  why4: "Instagram, Facebook, Reels",
  ctaCampaign: "Meine erste Kampagne erstellen",
  footerProduct: "Produkt",
  footerSupport: "Hilfe & Kontakt",
  footerTerms: "Nutzungsbedingungen",
  footerPrivacy: "Datenschutz",
  footerCookies: "Cookie-Richtlinie",
  footerCgu: "Allgemeine Geschäftsbedingungen",
  footerRights: "Alle Rechte vorbehalten",
  heroFormatsTitle: "Ihre Visuals, jedes Format",
  heroFormatsSub: "Export in der richtigen Größe für jedes Netzwerk in einem Klick. Keine komplizierte Software: erstellen, exportieren, teilen.",
  heroFormatInstagram: "Instagram",
  heroFormatInstagramSub: "Quadrat und Hochformat, postbereit. Perfekt für Feed und Stories.",
  heroFormatFacebook: "Facebook",
  heroFormatFacebookSub: "Querformat und Cover, Beiträge und Banner. Optimierte Maße.",
  heroFormatReels: "Reels",
  heroFormatReelsSub: "Hochformat für Stories und Kurzvideos. Ein Export, alle Kanäle.",
  sectionTrustTitle: "Märkte, die uns vertrauen",
  testimonial1Market: "Markt im Zentrum",
  testimonial1Quote: "Seit Easymarket AI läuft alles einfacher. Ich verwalte meine Promos täglich, ohne auf jemanden zu warten.",
  testimonial2Market: "Super Frisch",
  testimonial2Quote: "Meine Visuals sind in wenigen Klicks fertig. Ich teile sie direkt, ohne Grafiker.",
  testimonial3Market: "Gemüsehändler an der Ecke",
  testimonial3Quote: "Ich mache meine Promos jetzt täglich statt wöchentlich. Riesige Zeitersparnis.",
};

const translations: Record<Locale, LandingTranslations> = { fr, en, nl, de };

export function getTranslations(locale: string): LandingTranslations {
  const l = locale as Locale;
  return translations[l] ?? fr;
}
