/**
 * Suppression d'arrière-plan dans le navigateur (gratuit, sans API).
 * Utilise @imgly/background-removal : modèle ONNX téléchargé une fois, puis mis en cache.
 * Aucune clé API (remove.bg, Gemini, ChatGPT) n'est nécessaire.
 */

export type RemoveBackgroundSource = Blob | File | string;

/**
 * Supprime l'arrière-plan d'une image directement dans le navigateur.
 * Retourne un Blob PNG transparent. Premier appel : 1–2 min (téléchargement du modèle).
 * @param source - Blob, File, ou URL (relative/absolue) de l'image
 */
export async function removeBackgroundInBrowser(
  source: RemoveBackgroundSource
): Promise<Blob> {
  if (typeof window === "undefined") {
    throw new Error("removeBackgroundInBrowser doit être appelé côté client (navigateur).");
  }

  let input: Blob | string;
  if (source instanceof Blob) {
    input = source instanceof File ? source : new File([source], "image.png", { type: source.type || "image/png" });
  } else {
    input = source.startsWith("http") ? source : window.location.origin + source;
  }

  const removeBackground = (await import("@imgly/background-removal")).default;
  const blob = await removeBackground(input);
  return blob;
}
