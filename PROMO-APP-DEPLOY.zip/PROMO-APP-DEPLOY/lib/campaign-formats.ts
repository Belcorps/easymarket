/**
 * Dimensions officielles pour les visuels de campagnes (Instagram, Facebook, Reel).
 * Références: Instagram/Facebook 2024-2025.
 */

export type FormatType =
  | "instagram_post_portrait"  // 4:5 - recommandé feed
  | "instagram_post_square"   // 1:1
  | "facebook_post"            // 4:5
  | "reel";                    // 9:16 (Stories / Reels)

export const CAMPAIGN_FORMATS: Record<
  FormatType,
  { label: string; width: number; height: number; aspectRatio: string; aspectClass: string }
> = {
  instagram_post_portrait: {
    label: "Instagram Post (Portrait 4:5)",
    width: 1080,
    height: 1350,
    aspectRatio: "4:5",
    aspectClass: "aspect-[4/5]",
  },
  instagram_post_square: {
    label: "Instagram Post (Carré 1:1)",
    width: 1080,
    height: 1080,
    aspectRatio: "1:1",
    aspectClass: "aspect-square",
  },
  facebook_post: {
    label: "Facebook Post (4:5)",
    width: 1080,
    height: 1350,
    aspectRatio: "4:5",
    aspectClass: "aspect-[4/5]",
  },
  reel: {
    label: "Reel / Story (9:16)",
    width: 1080,
    height: 1920,
    aspectRatio: "9:16",
    aspectClass: "aspect-[9/16]",
  },
};

export const FORMAT_TYPES: FormatType[] = [
  "instagram_post_portrait",
  "instagram_post_square",
  "facebook_post",
  "reel",
];

export function getFormat(formatType: FormatType) {
  return CAMPAIGN_FORMATS[formatType] ?? CAMPAIGN_FORMATS.instagram_post_portrait;
}
