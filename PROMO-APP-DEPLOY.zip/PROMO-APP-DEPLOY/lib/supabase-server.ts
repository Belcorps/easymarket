import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const supabaseAdmin =
  url && serviceRoleKey
    ? createClient(url, serviceRoleKey, { auth: { persistSession: false } })
    : null;

const BUCKET = "uploads";

export type UploadResult = { url: string };

/**
 * Upload un buffer vers Supabase Storage (bucket public).
 * Retourne l’URL publique ou null si Supabase n’est pas configuré.
 */
export async function uploadToSupabase(
  path: string,
  buffer: Buffer,
  contentType: string
): Promise<UploadResult | null> {
  if (!supabaseAdmin) return null;
  const ext = contentType.includes("png") ? "png" : "jpg";
  const fullPath = `${path}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;
  const { data, error } = await supabaseAdmin.storage
    .from(BUCKET)
    .upload(fullPath, buffer, {
      contentType: contentType || "image/jpeg",
      upsert: false,
    });
  if (error) {
    console.error("Supabase upload error:", error);
    return null;
  }
  const { data: urlData } = supabaseAdmin.storage.from(BUCKET).getPublicUrl(data.path);
  return { url: urlData.publicUrl };
}
