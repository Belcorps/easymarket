"use client";

import Image from "next/image";

type LogoProps = {
  /** "full" = Easymarket AI, "short" = EMA */
  variant?: "full" | "short";
  /** Icon size in pixels */
  size?: number;
  /** Show only the icon, no text */
  iconOnly?: boolean;
  className?: string;
};

export function Logo({ variant = "full", size = 32, iconOnly = false, className = "" }: LogoProps) {
  const text = variant === "short" ? "EMA" : "EASYMARKET AI";

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      <div
        className="relative shrink-0 overflow-visible rounded-full bg-transparent"
        style={{ width: size, height: size }}
      >
        <Image
          src="/easymarket-logo.png?v=logo"
          alt="Easymarket AI"
          unoptimized
          width={size}
          height={size}
          className="object-contain"
          style={{ width: size, height: size, mixBlendMode: "lighten" }}
        />
      </div>
      {!iconOnly && (
        <span className="font-semibold tracking-wide text-white text-sm sm:text-base">
          {text}
        </span>
      )}
    </div>
  );
}
