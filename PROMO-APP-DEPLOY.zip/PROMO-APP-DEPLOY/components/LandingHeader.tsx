"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Logo } from "@/components/Logo";

type Props = {
  navLogin?: string;
  navRegister?: string;
};

export function LandingHeader({ navLogin = "Connexion", navRegister = "S'inscrire" }: Props) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 40);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 flex items-center justify-between px-6 py-4 max-w-6xl mx-auto w-full transition-all duration-300 ${
        scrolled
          ? "bg-[#0c0c1a]/80 backdrop-blur-xl border-b border-white/5 shadow-lg shadow-black/10"
          : "bg-transparent"
      }`}
    >
      <Link
        href="/"
        className="flex items-center gap-2 text-white hover:opacity-90 transition-opacity"
      >
        <Logo variant="full" size={32} className="[&_span]:text-white [&_span]:dark:text-white" />
      </Link>
      <nav className="flex items-center gap-3">
        <Link
          href="/login"
          className="px-4 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-colors font-medium text-sm"
        >
          {navLogin}
        </Link>
        <Link
          href="/register"
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-500 to-blue-600 text-white font-semibold text-sm hover:opacity-95 transition-opacity shadow-lg shadow-violet-500/25"
        >
          {navRegister}
        </Link>
      </nav>
    </header>
  );
}
