"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useRef, useEffect } from "react";
import { COOKIE_NAME, LOCALE_LABELS, type Locale } from "@/lib/i18n";
import type { LandingTranslations } from "@/lib/i18n";
import { setLocale } from "@/app/actions/locale";

type Props = {
  locale: Locale;
  t: Pick<
    LandingTranslations,
    | "footerProduct"
    | "footerSupport"
    | "footerTerms"
    | "footerPrivacy"
    | "footerCookies"
    | "footerCgu"
    | "footerRights"
    | "navLogin"
    | "navRegister"
  >;
};

const LOCALES: Locale[] = ["fr", "en", "nl", "de"];

export function LandingFooter({ locale, t }: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleSelect(newLocale: Locale) {
    await setLocale(newLocale);
    setOpen(false);
    router.refresh();
  }

  return (
    <footer className="relative z-10 py-10 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 lg:justify-between">
          {/* Sélecteur de langue */}
          <div className="relative" ref={ref}>
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              className="flex items-center gap-2 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10 hover:text-white transition-colors text-sm font-medium min-w-[180px] justify-between"
              aria-expanded={open}
              aria-haspopup="listbox"
              aria-label="Choisir la langue"
            >
              <span>{LOCALE_LABELS[locale]}</span>
              <span className="text-slate-500" aria-hidden>▼</span>
            </button>
            {open && (
              <ul
                role="listbox"
                className="absolute top-full left-0 mt-2 w-full min-w-[180px] rounded-xl bg-slate-900/95 border border-white/10 shadow-xl overflow-hidden z-50 max-h-60 overflow-y-auto"
              >
                {LOCALES.map((l) => (
                  <li key={l} role="option" aria-selected={l === locale}>
                    <button
                      type="button"
                      onClick={() => handleSelect(l)}
                      className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                        l === locale
                          ? "bg-violet-500/20 text-violet-300 font-medium"
                          : "text-slate-300 hover:bg-white/10 hover:text-white"
                      }`}
                    >
                      {LOCALE_LABELS[l]}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Liens légaux + Connexion / Inscription */}
          <div className="flex flex-col sm:flex-row gap-6 sm:gap-10">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                {t.footerSupport}
              </p>
              <ul className="flex flex-wrap gap-x-6 gap-y-1 text-sm">
                <li>
                  <Link
                    href="/contact"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    Contact
                  </Link>
                </li>
                <li>
                  <Link
                    href="/terms"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {t.footerTerms}
                  </Link>
                </li>
                <li>
                  <Link
                    href="/conditions-generales"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {t.footerCgu}
                  </Link>
                </li>
                <li>
                  <Link
                    href="/politique-confidentialite"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {t.footerPrivacy}
                  </Link>
                </li>
                <li>
                  <Link
                    href="/politique-cookies"
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {t.footerCookies}
                  </Link>
                </li>
              </ul>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <Link
                href="/login"
                className="text-slate-400 hover:text-white transition-colors font-medium"
              >
                {t.navLogin}
              </Link>
              <Link
                href="/register"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-violet-500 to-blue-600 text-white font-semibold hover:opacity-95 transition-opacity"
              >
                {t.navRegister}
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-white/5 flex flex-col gap-3 text-sm text-slate-500">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <Link
              href="/"
              className="font-medium text-slate-400 hover:text-white transition-colors"
            >
              Easymarket AI
            </Link>
            <p className="text-xs sm:text-sm">
              © {new Date().getFullYear()} Easymarket AI – {t.footerRights}
            </p>
            <div className="flex items-center gap-4 text-xs sm:text-sm">
              <a
                href="mailto:info@belcorps.com"
                className="inline-flex items-center gap-1 text-slate-400 hover:text-violet-200 transition-colors"
              >
                <span aria-hidden>✉️</span>
                <span className="hidden sm:inline">Email</span>
              </a>
              <a
                href="https://wa.me/32490111555"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-slate-400 hover:text-emerald-200 transition-colors"
              >
                <span aria-hidden>🟢</span>
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
