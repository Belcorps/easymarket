"use client";

import { getFormat, type FormatType } from "@/lib/campaign-formats";

export type TemplateProduct = {
  name: string;
  imageUrl: string | null;
  oldPrice: string;
  newPrice: string;
  unit?: string | null;
};

export type TemplateData = {
  marketName: string;
  products: TemplateProduct[];
  campaignName: string;
  startDate: string;
  endDate: string;
  showAddress: boolean;
  showPhone: boolean;
  language: string;
  currency: string;
};

type TemplateProps = { data: TemplateData; aspectClass: string };

const templates: Record<string, React.ComponentType<TemplateProps>> = {
  template1: Template1,
  template2: Template2,
  template3: Template3,
  template4: Template4,
  template5: Template5,
};

export function TemplatePreview({
  templateId,
  data,
  formatType = "instagram_post_portrait",
  className = "",
}: {
  templateId: string;
  data: TemplateData;
  formatType?: FormatType;
  className?: string;
}) {
  const T = templates[templateId] ?? Template1;
  const { aspectClass } = getFormat(formatType);
  return (
    <div className={className}>
      <T data={data} aspectClass={aspectClass} />
    </div>
  );
}

function ProductImage({ imageUrl }: { imageUrl: string | null }) {
  if (!imageUrl) return <span className="text-5xl">📦</span>;
  return <img src={imageUrl} alt="" className="w-full h-full object-contain" />;
}

function Template1({ data, aspectClass }: TemplateProps) {
  const p = data.products[0];
  return (
    <div className={`${aspectClass} max-w-md mx-auto rounded-xl overflow-hidden shadow-xl text-white p-5 flex flex-col`} style={{ background: "linear-gradient(145deg, #b91c1c 0%, #7f1d1d 50%, #450a0a 100%)" }}>
      <div className="text-center mb-2">
        <span className="text-amber-300 font-bold text-lg tracking-wide">{data.marketName}</span>
      </div>
      <h2 className="text-2xl font-bold text-center text-amber-200 mb-1">RAMAZAN</h2>
      <p className="text-center text-sm font-semibold mb-2">SUPER PROMO</p>
      <p className="text-center text-xs opacity-90 mb-3">
        {data.startDate || "—"} → Offre du jour
      </p>
      <div className="flex-1 flex items-center justify-center gap-5 min-h-0">
        {p ? (
          <>
            <div className="flex-1 text-center min-w-0">
              <p className="text-xs text-amber-200/90 mb-1">Super prix</p>
              <p className="text-2xl font-bold">{p.newPrice}{data.currency}</p>
              {p.oldPrice && (
                <p className="text-sm line-through opacity-80">{p.oldPrice}{data.currency}</p>
              )}
              <p className="text-xs mt-1 break-words">{p.name}</p>
            </div>
            <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-xl bg-white/15 flex items-center justify-center overflow-hidden flex-shrink-0 shadow-lg">
              <ProductImage imageUrl={p.imageUrl} />
            </div>
          </>
        ) : (
          <p className="text-sm opacity-70">Ajoutez un produit</p>
        )}
      </div>
      {data.showPhone && (
        <p className="text-center text-sm mt-2 opacity-90">0490 11 15 55</p>
      )}
    </div>
  );
}

function Template2({ data, aspectClass }: TemplateProps) {
  const p = data.products[0];
  return (
    <div className={`${aspectClass} max-w-md mx-auto rounded-xl overflow-hidden shadow-xl bg-gradient-to-br from-blue-800 to-blue-600 text-white p-5 flex flex-col`}>
      <div className="flex justify-between items-start mb-3">
        <span className="font-bold text-sm">{data.marketName}</span>
        <span className="text-xs bg-white/20 px-2 py-0.5 rounded">-60%</span>
      </div>
      <h2 className="text-xl font-bold text-center mb-2">SUPER KAMPANYA</h2>
      <div className="flex-1 flex flex-col items-center justify-center">
        {p ? (
          <>
            <div className="w-32 h-32 rounded-xl bg-white/15 flex items-center justify-center overflow-hidden mb-3 shadow-lg">
              <ProductImage imageUrl={p.imageUrl} />
            </div>
            <p className="font-bold text-2xl">{p.newPrice}{data.currency}</p>
            {p.oldPrice && (
              <p className="text-sm line-through opacity-80">{p.oldPrice}{data.currency}</p>
            )}
            <p className="text-xs mt-1">{p.name}</p>
          </>
        ) : (
          <p className="text-sm opacity-70">Ajoutez un produit</p>
        )}
      </div>
      <p className="text-center text-xs opacity-80">
        {data.startDate || "—"} - {data.endDate || "—"}
      </p>
    </div>
  );
}

function Template3({ data, aspectClass }: TemplateProps) {
  const p = data.products[0];
  return (
    <div className={`${aspectClass} max-w-sm mx-auto rounded-xl overflow-hidden shadow-xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white p-5 flex flex-col`}>
      <p className="text-center text-xs font-medium uppercase tracking-wider text-emerald-200 mb-2">
        {data.marketName}
      </p>
      <h2 className="text-xl font-bold text-center text-emerald-100 mb-3">KAMPANYA</h2>
      <div className="flex-1 flex items-center justify-center gap-3">
        {p ? (
          <>
            <div className="w-28 h-28 rounded-lg bg-white/15 flex items-center justify-center overflow-hidden shadow-lg">
              <ProductImage imageUrl={p.imageUrl} />
            </div>
            <div>
              <p className="text-2xl font-bold">{p.newPrice}{data.currency}</p>
              {p.oldPrice && (
                <p className="text-sm line-through">{p.oldPrice}{data.currency}</p>
              )}
              <p className="text-xs mt-1">{p.name}</p>
            </div>
          </>
        ) : (
          <p className="text-sm opacity-70">Ajoutez un produit</p>
        )}
      </div>
      <p className="text-center text-xs mt-2">
        {data.startDate || "—"} - {data.endDate || "—"}
      </p>
    </div>
  );
}

function Template4({ data, aspectClass }: TemplateProps) {
  const p = data.products[0];
  return (
    <div className={`${aspectClass} max-w-md mx-auto rounded-xl overflow-hidden shadow-xl bg-slate-800 text-white p-5 flex flex-col`}>
      <div className="text-right text-xs text-slate-400 mb-2">{data.marketName}</div>
      <h2 className="text-2xl font-bold text-center text-amber-400 mb-1">{data.campaignName || "Promo"}</h2>
      <p className="text-center text-slate-400 text-sm mb-4">
        {data.startDate || "—"} / {data.endDate || "—"}
      </p>
      <div className="flex-1 flex items-center justify-center">
        {p ? (
          <div className="text-center">
            <div className="w-28 h-28 rounded-lg bg-slate-700 flex items-center justify-center overflow-hidden mx-auto mb-2">
              <ProductImage imageUrl={p.imageUrl} />
            </div>
            <p className="text-xl font-bold text-amber-400">{p.newPrice}{data.currency}</p>
            {p.oldPrice && (
              <p className="text-sm line-through text-slate-400">{p.oldPrice}{data.currency}</p>
            )}
            <p className="text-xs text-slate-300 mt-1">{p.name}</p>
          </div>
        ) : (
          <p className="text-sm text-slate-500">Ajoutez un produit</p>
        )}
      </div>
      {data.showPhone && (
        <p className="text-center text-slate-500 text-xs mt-2">Tél. affiché</p>
      )}
    </div>
  );
}

function Template5({ data, aspectClass }: TemplateProps) {
  const p = data.products[0];
  return (
    <div className={`${aspectClass} max-w-md mx-auto rounded-xl overflow-hidden shadow-xl bg-gradient-to-br from-orange-500 to-amber-600 text-white p-5 flex flex-col`}>
      <p className="text-center font-bold text-sm text-amber-100 mb-1">{data.marketName}</p>
      <h2 className="text-2xl font-bold text-center mb-2">OFFRE DU JOUR</h2>
      <p className="text-center text-sm opacity-90 mb-4">{data.startDate || "—"}</p>
      <div className="flex-1 flex items-center justify-center gap-4">
        {p ? (
          <>
            <div className="w-28 h-28 rounded-xl bg-white/20 flex items-center justify-center overflow-hidden shadow-lg">
              <ProductImage imageUrl={p.imageUrl} />
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold">{p.newPrice}{data.currency}</p>
              {p.oldPrice && (
                <p className="text-sm line-through opacity-80">{p.oldPrice}{data.currency}</p>
              )}
              <p className="text-xs mt-1">{p.name}</p>
            </div>
          </>
        ) : (
          <p className="text-sm opacity-80">Ajoutez un produit</p>
        )}
      </div>
      <p className="text-center text-xs opacity-80 mt-2">Jusqu&apos;à épuisement des stocks</p>
    </div>
  );
}
