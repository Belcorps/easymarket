"use client";

import { useState, useEffect } from "react";

type T = {
  testimonial1Market: string;
  testimonial1Quote: string;
  testimonial2Market: string;
  testimonial2Quote: string;
  testimonial3Market: string;
  testimonial3Quote: string;
};

export function TestimonialsCarousel({ t }: { t: T }) {
  const [index, setIndex] = useState(0);
  const items = [
    { market: t.testimonial1Market, quote: t.testimonial1Quote },
    { market: t.testimonial2Market, quote: t.testimonial2Quote },
    { market: t.testimonial3Market, quote: t.testimonial3Quote },
  ];

  useEffect(() => {
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % items.length);
    }, 5000);
    return () => clearInterval(id);
  }, [items.length]);

  return (
    <div className="relative max-w-2xl mx-auto">
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-6 sm:p-8 min-h-[160px]">
        {items.map((item, i) => (
          <div
            key={item.market}
            className={`absolute inset-0 p-6 sm:p-8 transition-all duration-500 ease-out ${
              i === index
                ? "opacity-100 translate-x-0"
                : "opacity-0 pointer-events-none translate-x-8"
            }`}
          >
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-4">
              &ldquo;{item.quote}&rdquo;
            </p>
            <p className="text-violet-300 font-semibold text-sm">{item.market}</p>
          </div>
        ))}
      </div>
      <div className="flex justify-center gap-2 mt-4">
        {items.map((_, i) => (
          <button
            key={i}
            type="button"
            onClick={() => setIndex(i)}
            className={`h-2 rounded-full transition-all ${
              i === index ? "w-6 bg-violet-500" : "w-2 bg-white/30 hover:bg-white/50"
            }`}
            aria-label={`Témoignage ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
